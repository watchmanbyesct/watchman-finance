# Watchman Finance Shared Library Stubs

This folder contains starter TypeScript stubs for the shared Supabase permission and audit utility library.

Included areas:
- auth resolution
- request context resolution
- permission enforcement
- entity scope enforcement
- maker-checker control
- audit payload building
- audit logging
- typed application errors

These are starter files and still need:
- real Supabase server client wiring
- real feature-flag and module-entitlement checks
- repository integration
- unit and integration tests
- environment-specific configuration
