export type UUID = string;

export type SourceChannel = "web" | "api" | "integration" | "system";

export interface RequestContext {
  authUserId: UUID;
  platformUserId: UUID;
  tenantId: UUID;
  entityIds: UUID[];
  roleCodes: string[];
  permissions: string[];
  correlationId: string;
  sourceChannel: SourceChannel;
}

export interface SessionUser {
  authUserId: UUID;
  email?: string | null;
}

export interface PlatformUserRecord {
  id: UUID;
  auth_user_id: UUID;
  status?: string | null;
}

export interface MembershipRecord {
  tenant_id: UUID;
  entity_ids?: UUID[] | null;
  role_codes?: string[] | null;
  membership_status?: string | null;
}
