import type { UUID } from "./auth";

export interface AuditPayload {
  tenantId?: UUID;
  entityId?: UUID;
  actorPlatformUserId?: UUID;
  moduleKey: string;
  actionCode: string;
  targetTable: string;
  targetRecordId?: UUID;
  oldValues?: unknown;
  newValues?: unknown;
  metadata?: unknown;
  sourceChannel?: string;
}

export interface BuildAuditPayloadInput {
  moduleKey: string;
  actionCode: string;
  targetTable: string;
  targetRecordId?: UUID;
  entityId?: UUID;
  oldValues?: unknown;
  newValues?: unknown;
  metadata?: unknown;
}
