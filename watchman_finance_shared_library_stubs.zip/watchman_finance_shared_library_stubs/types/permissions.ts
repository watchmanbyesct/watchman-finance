import type { UUID } from "./auth";

export interface PermissionCheckOptions {
  allowIfAny?: boolean;
  enforceEntityScope?: boolean;
  entityId?: UUID;
}

export interface MakerCheckerOptions {
  actorPlatformUserId: UUID;
  createdByPlatformUserId?: UUID | null;
  workflow: string;
}

export interface ModuleAccessOptions {
  moduleKey: string;
  requiredFlagKey?: string;
}
