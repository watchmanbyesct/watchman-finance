import type { SessionUser } from "../../types/auth";
import type { SupabaseLikeClient } from "../db/supabase-server";
import { AppError } from "../errors/app-error";

export async function resolveSession(client: SupabaseLikeClient): Promise<SessionUser> {
  const result = await client.auth.getUser();

  if (result.error) {
    throw new AppError("auth:session_lookup_failed", result.error.message, 401);
  }

  if (!result.data.user?.id) {
    throw new AppError("auth:unauthenticated", "Authenticated session required.", 401);
  }

  return {
    authUserId: result.data.user.id,
    email: result.data.user.email ?? null,
  };
}
