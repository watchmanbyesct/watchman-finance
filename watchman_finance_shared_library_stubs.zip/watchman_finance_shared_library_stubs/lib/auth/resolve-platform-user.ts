import type { MembershipRecord, PlatformUserRecord } from "../../types/auth";
import type { DbClient } from "../db/transaction";
import { AppError } from "../errors/app-error";

export interface ResolvedPlatformUser {
  platformUser: PlatformUserRecord;
  memberships: MembershipRecord[];
}

export async function resolvePlatformUser(
  db: DbClient,
  authUserId: string,
): Promise<ResolvedPlatformUser> {
  const platformUserResult = await db.query<PlatformUserRecord>(
    `
    select id, auth_user_id, status
    from public.platform_users
    where auth_user_id = $1
    limit 1
    `,
    [authUserId],
  );

  const platformUser = platformUserResult.rows[0];
  if (!platformUser?.id) {
    throw new AppError(
      "auth:platform_user_not_found",
      "No platform user mapping exists for this authenticated user.",
      403,
      { authUserId },
    );
  }

  const membershipsResult = await db.query<MembershipRecord>(
    `
    select
      tum.tenant_id,
      tum.membership_status,
      coalesce(
        array(
          select distinct teu.entity_id
          from public.tenant_entity_user_scopes teu
          where teu.tenant_membership_id = tum.id
        ),
        '{}'::uuid[]
      ) as entity_ids,
      coalesce(
        array(
          select distinct r.code
          from public.tenant_user_role_assignments tura
          join public.roles r on r.id = tura.role_id
          where tura.tenant_membership_id = tum.id
        ),
        '{}'::text[]
      ) as role_codes
    from public.tenant_user_memberships tum
    where tum.platform_user_id = $1
      and tum.membership_status = 'active'
    `,
    [platformUser.id],
  );

  return {
    platformUser,
    memberships: membershipsResult.rows,
  };
}
