import { AppError } from "./app-error";

export class PermissionError extends AppError {
  constructor(permission: string, details?: unknown) {
    super(
      "forbidden:permission_missing",
      `Missing required permission: ${permission}`,
      403,
      details,
    );
    this.name = "PermissionError";
  }
}
