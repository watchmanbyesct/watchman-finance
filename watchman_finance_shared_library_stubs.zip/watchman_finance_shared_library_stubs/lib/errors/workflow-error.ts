import { AppError } from "./app-error";

export class WorkflowError extends AppError {
  constructor(code: string, message: string, details?: unknown) {
    super(code, message, 409, details);
    this.name = "WorkflowError";
  }
}
