import { AppError } from "./app-error";

export class ScopeError extends AppError {
  constructor(entityId: string, details?: unknown) {
    super(
      "forbidden:entity_scope_mismatch",
      `User does not have scope for entity: ${entityId}`,
      403,
      details,
    );
    this.name = "ScopeError";
  }
}
