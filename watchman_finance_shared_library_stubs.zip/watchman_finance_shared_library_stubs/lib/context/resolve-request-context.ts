import type { RequestContext, SourceChannel } from "../../types/auth";
import type { DbClient } from "../db/transaction";
import type { SupabaseLikeClient } from "../db/supabase-server";
import { resolveSession } from "../auth/resolve-session";
import { resolvePlatformUser } from "../auth/resolve-platform-user";
import { assertTenantContext } from "./assert-tenant-context";
import { getEffectivePermissions } from "../permissions/get-effective-permissions";

export interface ResolveRequestContextInput {
  db: DbClient;
  supabase: SupabaseLikeClient;
  tenantId: string;
  sourceChannel?: SourceChannel;
  correlationId?: string;
}

export async function resolveRequestContext(
  input: ResolveRequestContextInput,
): Promise<RequestContext> {
  const session = await resolveSession(input.supabase);
  const resolved = await resolvePlatformUser(input.db, session.authUserId);
  const membership = assertTenantContext(resolved.memberships, input.tenantId);
  const permissions = await getEffectivePermissions(
    input.db,
    resolved.platformUser.id,
    membership.tenant_id,
  );

  return {
    authUserId: session.authUserId,
    platformUserId: resolved.platformUser.id,
    tenantId: membership.tenant_id,
    entityIds: membership.entity_ids ?? [],
    roleCodes: membership.role_codes ?? [],
    permissions,
    correlationId:
      input.correlationId ?? `corr_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
    sourceChannel: input.sourceChannel ?? "web",
  };
}
