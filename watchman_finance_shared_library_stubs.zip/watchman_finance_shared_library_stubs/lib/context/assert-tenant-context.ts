import type { MembershipRecord } from "../../types/auth";
import { AppError } from "../errors/app-error";

export function assertTenantContext(
  memberships: MembershipRecord[],
  tenantId?: string | null,
): MembershipRecord {
  if (!tenantId) {
    throw new AppError(
      "context:tenant_missing",
      "A tenant context is required for this request.",
      400,
    );
  }

  const membership = memberships.find(
    (row) => row.tenant_id === tenantId && row.membership_status === "active",
  );

  if (!membership) {
    throw new AppError(
      "context:tenant_access_denied",
      "The current user does not have access to the requested tenant.",
      403,
      { tenantId },
    );
  }

  return membership;
}
