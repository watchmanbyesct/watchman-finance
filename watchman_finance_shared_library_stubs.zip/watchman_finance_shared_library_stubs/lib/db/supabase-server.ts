export interface SupabaseLikeAuthResult {
  data: {
    user: {
      id: string;
      email?: string | null;
    } | null;
  };
  error: Error | null;
}

export interface SupabaseLikeClient {
  auth: {
    getUser(): Promise<SupabaseLikeAuthResult>;
  };
  from(table: string): {
    select(columns: string): any;
    insert(values: Record<string, unknown> | Record<string, unknown>[]): any;
  };
}

/**
 * Replace this factory with your real Supabase server client constructor.
 */
export function getSupabaseServerClient(client: SupabaseLikeClient): SupabaseLikeClient {
  return client;
}
