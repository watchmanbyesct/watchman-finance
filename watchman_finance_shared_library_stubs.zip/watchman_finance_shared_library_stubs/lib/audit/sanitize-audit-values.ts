const REDACTED_KEYS = [
  "password",
  "token",
  "access_token",
  "refresh_token",
  "routing_number",
  "account_number",
  "ssn",
  "tax_id",
  "bank_account_number",
];

function sanitizeValue(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(sanitizeValue);
  }

  if (value && typeof value === "object") {
    const obj = value as Record<string, unknown>;
    const sanitized: Record<string, unknown> = {};

    for (const [key, nestedValue] of Object.entries(obj)) {
      if (REDACTED_KEYS.includes(key.toLowerCase())) {
        sanitized[key] = "[REDACTED]";
      } else {
        sanitized[key] = sanitizeValue(nestedValue);
      }
    }

    return sanitized;
  }

  return value;
}

export function sanitizeAuditValues<T>(value: T): T {
  return sanitizeValue(value) as T;
}
