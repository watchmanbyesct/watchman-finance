export const AuditActionCodes = {
  AR_INVOICE_DRAFT_CREATE: "ar.invoice.draft.create",
  AR_INVOICE_ISSUE: "ar.invoice.issue",
  AP_BILL_APPROVE: "ap.bill.approve",
  PAYROLL_RUN_CREATE: "payroll.run.create",
  PAYROLL_RUN_FINALIZE: "payroll.run.finalize",
  LEAVE_REQUEST_APPROVE: "leave.request.approve",
  BANK_RECONCILIATION_APPROVE: "bank.reconciliation.approve",
  INVENTORY_RECEIVE: "inventory.receive",
  INVENTORY_ADJUST: "inventory.adjust",
  RELEASE_VERSION_APPROVE: "release.version.approve",
} as const;
