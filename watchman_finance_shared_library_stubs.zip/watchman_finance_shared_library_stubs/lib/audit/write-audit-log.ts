import type { AuditPayload } from "../../types/audit";
import type { DbClient } from "../db/transaction";
import { sanitizeAuditValues } from "./sanitize-audit-values";

export async function writeAuditLog(db: DbClient, payload: AuditPayload): Promise<void> {
  const oldValues = sanitizeAuditValues(payload.oldValues ?? null);
  const newValues = sanitizeAuditValues(payload.newValues ?? null);
  const metadata = sanitizeAuditValues(payload.metadata ?? null);

  await db.query(
    `
    insert into public.audit_logs (
      tenant_id,
      entity_id,
      actor_platform_user_id,
      module_key,
      action_code,
      target_table,
      target_record_id,
      old_values_json,
      new_values_json,
      metadata_json,
      source_channel
    )
    values ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9::jsonb,$10::jsonb,$11)
    `,
    [
      payload.tenantId ?? null,
      payload.entityId ?? null,
      payload.actorPlatformUserId ?? null,
      payload.moduleKey,
      payload.actionCode,
      payload.targetTable,
      payload.targetRecordId ?? null,
      JSON.stringify(oldValues),
      JSON.stringify(newValues),
      JSON.stringify(metadata),
      payload.sourceChannel ?? "api",
    ],
  );
}
