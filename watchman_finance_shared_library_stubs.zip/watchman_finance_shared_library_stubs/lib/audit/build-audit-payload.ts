import type { RequestContext } from "../../types/auth";
import type { AuditPayload, BuildAuditPayloadInput } from "../../types/audit";

export function buildAuditPayload(
  ctx: RequestContext,
  input: BuildAuditPayloadInput,
): AuditPayload {
  return {
    tenantId: ctx.tenantId,
    entityId: input.entityId,
    actorPlatformUserId: ctx.platformUserId,
    moduleKey: input.moduleKey,
    actionCode: input.actionCode,
    targetTable: input.targetTable,
    targetRecordId: input.targetRecordId,
    oldValues: input.oldValues,
    newValues: input.newValues,
    metadata: {
      correlationId: ctx.correlationId,
      ...(typeof input.metadata === "object" && input.metadata !== null
        ? (input.metadata as Record<string, unknown>)
        : { value: input.metadata }),
    },
    sourceChannel: ctx.sourceChannel,
  };
}
