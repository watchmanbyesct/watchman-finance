import type { AuditPayload } from "../../types/audit";
import type { DbClient } from "../db/transaction";
import { writeAuditLog } from "./write-audit-log";

export async function writeBulkAuditLog(db: DbClient, payloads: AuditPayload[]): Promise<void> {
  for (const payload of payloads) {
    await writeAuditLog(db, payload);
  }
}
