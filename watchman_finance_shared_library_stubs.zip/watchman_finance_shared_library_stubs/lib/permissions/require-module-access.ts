import type { RequestContext } from "../../types/auth";
import { AppError } from "../errors/app-error";

/**
 * Stub implementation.
 * Replace this with tenant feature-flag and entitlement lookup logic.
 */
export async function requireModuleAccess(
  _ctx: RequestContext,
  _moduleKey: string,
): Promise<void> {
  return;
}

/**
 * Example alternate helper for callers who want a sync no-op placeholder.
 */
export function assertModuleAccessEnabled(enabled: boolean, moduleKey: string): void {
  if (!enabled) {
    throw new AppError(
      "forbidden:module_disabled",
      `Module is not enabled for this tenant: ${moduleKey}`,
      403,
    );
  }
}
