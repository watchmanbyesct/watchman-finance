import type { RequestContext } from "../../types/auth";
import { ScopeError } from "../errors/scope-error";

export function requireEntityScope(ctx: RequestContext, entityId: string): void {
  if (!ctx.entityIds.includes(entityId)) {
    throw new ScopeError(entityId, {
      platformUserId: ctx.platformUserId,
      tenantId: ctx.tenantId,
    });
  }
}
