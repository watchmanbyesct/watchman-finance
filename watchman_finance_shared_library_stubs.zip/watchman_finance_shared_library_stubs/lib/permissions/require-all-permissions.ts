import type { RequestContext } from "../../types/auth";
import { PermissionError } from "../errors/permission-error";

export function requireAllPermissions(ctx: RequestContext, permissions: string[]): void {
  const missing = permissions.filter((permission) => !ctx.permissions.includes(permission));
  if (missing.length > 0) {
    throw new PermissionError(missing.join(", "), {
      platformUserId: ctx.platformUserId,
      tenantId: ctx.tenantId,
    });
  }
}
