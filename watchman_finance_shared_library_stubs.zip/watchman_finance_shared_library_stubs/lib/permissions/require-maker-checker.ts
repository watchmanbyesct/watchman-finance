import type { MakerCheckerOptions } from "../../types/permissions";
import { WorkflowError } from "../errors/workflow-error";

export function requireMakerChecker(options: MakerCheckerOptions): void {
  if (
    options.createdByPlatformUserId &&
    options.actorPlatformUserId === options.createdByPlatformUserId
  ) {
    throw new WorkflowError(
      "workflow:maker_checker_violation",
      `Maker-checker control violated for workflow: ${options.workflow}`,
      options,
    );
  }
}
