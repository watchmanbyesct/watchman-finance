import type { RequestContext } from "../../types/auth";
import { PermissionError } from "../errors/permission-error";

export function requirePermission(ctx: RequestContext, permission: string): void {
  if (!ctx.permissions.includes(permission)) {
    throw new PermissionError(permission, {
      platformUserId: ctx.platformUserId,
      tenantId: ctx.tenantId,
    });
  }
}
