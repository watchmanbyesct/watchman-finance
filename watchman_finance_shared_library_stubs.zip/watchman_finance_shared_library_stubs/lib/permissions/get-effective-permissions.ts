import type { DbClient } from "../db/transaction";

export async function getEffectivePermissions(
  db: DbClient,
  platformUserId: string,
  tenantId: string,
): Promise<string[]> {
  const result = await db.query<{ permission_code: string }>(
    `
    select distinct p.code as permission_code
    from public.tenant_user_memberships tum
    join public.tenant_user_role_assignments tura
      on tura.tenant_membership_id = tum.id
    join public.role_permissions rp
      on rp.role_id = tura.role_id
    join public.permissions p
      on p.id = rp.permission_id
    where tum.platform_user_id = $1
      and tum.tenant_id = $2
      and tum.membership_status = 'active'
    `,
    [platformUserId, tenantId],
  );

  return result.rows.map((row) => row.permission_code);
}
