import type { RequestContext } from "../../types/auth";
import { PermissionError } from "../errors/permission-error";

export function requireAnyPermission(ctx: RequestContext, permissions: string[]): void {
  if (!permissions.some((permission) => ctx.permissions.includes(permission))) {
    throw new PermissionError(permissions.join(" OR "), {
      platformUserId: ctx.platformUserId,
      tenantId: ctx.tenantId,
    });
  }
}
